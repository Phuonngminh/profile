// let a = 10;
// set a value of 10 
// console.log(a);
// alert(a);
var x = prompt("Nhập số vào: ");
document.write(x);